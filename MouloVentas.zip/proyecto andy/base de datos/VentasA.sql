create database VentasA

CREATE TABLE empleados (
  usuario varchar(30) primary key,
  contrase�a numeric(30)  NOT NULL,
  dpi varchar(30)  NOT NULL,
  fechaingreso varchar(30)  NOT NULL,
  correo varchar(30)  NOT NULL,
  telefono numeric (30) NOT NULL
) 


CREATE TABLE proveedor (
  codigoprove numeric (30 )primary key,
  nombreprove varchar(30) NOT NULL,
  telefonoprove numeric (30) NOT NULL,
  direccionprove varchar (30) NOT NULL
 ) 


CREATE TABLE productos (
   codigoprod numeric (30 )primary key,
   descripcionprod varchar(30) NOT NULL,
   cantidadprod numeric (30) NOT NULL,
   precioprod numeric (30) NOT NULL,
   estado varchar(30) NOT NULL,
   codigoprove numeric (30 ) references proveedor not null
) 



CREATE TABLE clientes (
   codclie numeric (30 )primary key,
   nitclie numeric (30) NOT NULL,
   telefonoclie numeric (30) NOT NULL,
   nombreclie varchar (30) NOT NULL,
   direccion varchar (30) NOT NULL,
) 


CREATE TABLE ventas (
   codigovent numeric (30 )primary key,
   descripcionvent varchar(30) NOT NULL,
   cantidadvent numeric (30) NOT NULL,
   preciovent numeric (30) NOT NULL,
   fecha varchar (30) NOT NULL,
   total varchar (30) NOT NULL,
   codclie numeric (30 ) references clientes not null,
   usuario varchar(30) references empleados not null
   ) 

CREATE TABLE detalleventa (
   dtvent numeric (30 )primary key,
   codigovent numeric (30 ) references ventas not null,
   codigoprod numeric (30 ) references productos not null,
   ) 


   insert into empleados( usuario,contrase�a,dpi,fechaingreso,correo, telefono) values ('admin', '123', '123456789', 'GUA, 08 de Nov del 2021', 'admin@gmail.com','12345678')

   SELECT * from empleados